//
//  LeftBubble.swift
//  BookCore
//
//  Created by dominator on 15/05/20.
//

import SwiftUI

struct RightBubble: Shape{
    let cornerRadius: CGFloat
    func path(in rect: CGRect) -> Path {
        Path { path in
            path.move(to: CGPoint(x: rect.minX, y: rect.minY + cornerRadius))
            path.addArc(center: CGPoint(x: rect.minX + cornerRadius, y: rect.minY + cornerRadius), radius: cornerRadius, startAngle: .degrees(-180), endAngle: .degrees(-90), clockwise: false)
            path.addLine(to: CGPoint(x: rect.maxX, y: 0))
            path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - cornerRadius))
            path.addArc(center: CGPoint(x: rect.maxX - cornerRadius, y: rect.maxY - cornerRadius), radius: cornerRadius, startAngle: .degrees(0), endAngle: .degrees(90), clockwise: false)
            path.addLine(to: CGPoint(x: rect.minX + cornerRadius, y: rect.maxY))
            path.addArc(center: CGPoint(x: rect.minX + cornerRadius, y: rect.maxY - cornerRadius), radius: cornerRadius, startAngle: .degrees(90), endAngle: .degrees(-180), clockwise: false)
            path.closeSubpath()
        }
    }
}

public struct BubbleBackground: ViewModifier {
    public func body(content: Content) -> some View {
        content
        .background(
            RightBubble(cornerRadius: 10)
            .fill(
                Color(UIColor.secondarySystemFill)
            )
        )
    }
    
}

public extension View{
    func addBubbleBackground() -> some View{
        self
            .padding()
            .modifier(BubbleBackground())
    }
}
