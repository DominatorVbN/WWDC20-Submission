//
//  ViewSnapshot.swift
//  BookCore
//
//  Created by dominator on 15/05/20.
//

import SwiftUI
import UIKit

public struct HostingWindowKey: EnvironmentKey {
    public typealias WrappedValue = UIWindow
    public typealias Value = () -> WrappedValue?
    public static let defaultValue: Self.Value = { nil }
}

public extension EnvironmentValues {
    var hostingWindow: HostingWindowKey.Value {
        get {
            return self[HostingWindowKey.self]
        }
        set {
            self[HostingWindowKey.self] = newValue
        }
    }
}

public extension UIView {
    func asImage(rect: CGRect) -> UIImage {
        let renderer = UIGraphicsImageRenderer(bounds: rect)
        return renderer.image { rendererContext in
            layer.render(in: rendererContext.cgContext)
        }
    }
}


import PlaygroundSupport
public extension PlaygroundPage{
    func setLiveViewForSnapshot<Content: View>(_ view: Content){
        let window = UIWindow()
        let contentView = view
            .environment(\.hostingWindow, { [weak window] in
                return window })
        window.rootViewController = UIHostingController(rootView: contentView)
        self.liveView = window
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.03) {
            window.makeKeyAndVisible()
        }
    }
}
