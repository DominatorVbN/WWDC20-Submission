//
//  Color+.swift
//  BookCore
//
//  Created by dominator on 09/05/20.
//


import SwiftUI

public extension Color{
    static let lightBlue    = Color(#colorLiteral(red: 0.2639712691, green: 0.7017275691, blue: 0.9723640084, alpha: 1))
    static let darkBlue     = Color(#colorLiteral(red: 0.0589934811, green: 0.3185711503, blue: 0.8577244878, alpha: 1))
    static let blueHueStart = Color(#colorLiteral(red: 0.2285425961, green: 0.5784165859, blue: 0.6895257831, alpha: 1))
    static let blueHueEnd   = Color(#colorLiteral(red: 0.4271130264, green: 0.8364676833, blue: 0.9309514165, alpha: 1))
    static let redHueStart  = Color(#colorLiteral(red: 0.7387117147, green: 0.3052827716, blue: 0.6135740876, alpha: 1))
    static let redHueEnd    = Color(#colorLiteral(red: 0.9282850623, green: 0.2315128148, blue: 0.3473922014, alpha: 1))
}
