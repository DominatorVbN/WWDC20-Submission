//
//  FireworkView.swift
//  BookCore
//
//  Created by dominator on 14/05/20.
//

import UIKit
import SwiftUI

public class FireworkVC: UIViewController{
    let particlesLayer = CAEmitterLayer()
    
    override public func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        setUpFirework()
    }
    
    func setUpFirework(){
        let size = CGSize(width: self.view.frame.width, height: self.view.frame.height)
        let host = UIView(frame: CGRect(x: 0.0, y: 0.0, width: size.width, height: size.height))
        host.backgroundColor = .clear
        self.view.addSubview(host)
        
        particlesLayer.frame = CGRect(x: 0.0, y: 0.0, width: size.width, height: size.height)
        
        host.layer.addSublayer(particlesLayer)
        host.layer.masksToBounds = true
        
        particlesLayer.backgroundColor = UIColor.clear.cgColor
        particlesLayer.emitterShape = .point
        particlesLayer.emitterPosition = CGPoint(x:  self.view.frame.midX, y: self.view.frame.maxY)
        particlesLayer.emitterSize = CGSize(width: 0.0, height: 0.0)
        particlesLayer.emitterMode = .outline
        particlesLayer.renderMode = .additive
        
        
        let parentCell = CAEmitterCell()
        
        parentCell.name = "Parent"
        parentCell.birthRate = 5.0
        parentCell.lifetime = 2.5
        parentCell.velocity = 300.0
        parentCell.velocityRange = 100.0
        parentCell.yAcceleration = -100.0
        parentCell.emissionLongitude = -90.0 * (.pi / 180.0)
        parentCell.emissionRange = 45.0 * (.pi / 180.0)
        parentCell.scale = 0.0
        parentCell.color = UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        parentCell.redRange = 0.9
        parentCell.greenRange = 0.9
        parentCell.blueRange = 0.9
        
        
        
        let sparkImage = UIImage(named: "spark")?.cgImage
        
        let trailCell = CAEmitterCell()
        trailCell.contents = sparkImage
        trailCell.name = "Trail"
        trailCell.birthRate = 45.0
        trailCell.lifetime = 0.5
        trailCell.beginTime = 0.01
        trailCell.duration = 1.7
        trailCell.velocity = 80.0
        trailCell.velocityRange = 100.0
        trailCell.xAcceleration = 100.0
        trailCell.yAcceleration = 350.0
        trailCell.emissionLongitude = -360.0 * (.pi / 180.0)
        trailCell.emissionRange = 22.5 * (.pi / 180.0)
        trailCell.scale = 0.5
        trailCell.scaleSpeed = 0.13
        trailCell.alphaSpeed = -0.7
        trailCell.color = UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        
        
        let fireworkCell = CAEmitterCell()
        fireworkCell.contents = sparkImage
        fireworkCell.name = "Firework"
        fireworkCell.birthRate = 20000.0
        fireworkCell.lifetime = 15.0
        fireworkCell.beginTime = 1.6
        fireworkCell.duration = 0.1
        fireworkCell.velocity = 190.0
        fireworkCell.yAcceleration = 80.0
        fireworkCell.emissionRange = 360.0 * (.pi / 180.0)
        fireworkCell.spin = 114.6 * (.pi / 180.0)
        fireworkCell.scale = 0.1
        fireworkCell.scaleSpeed = 0.09
        fireworkCell.alphaSpeed = -0.7
        fireworkCell.color = UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0).cgColor
        
        parentCell.emitterCells = [trailCell, fireworkCell]
        
        particlesLayer.emitterCells = [parentCell]
    }
}

public struct FireworkView: UIViewControllerRepresentable {
    public init() {}
    public func makeUIViewController(context: UIViewControllerRepresentableContext<FireworkView>) -> FireworkVC {
        return FireworkVC()
    }

    public func updateUIViewController(_ uiViewController: FireworkVC, context: UIViewControllerRepresentableContext<FireworkView>) {
        uiViewController.particlesLayer.emitterPosition = CGPoint(x:  uiViewController.view.frame.midX, y: uiViewController.view.frame.maxY)
    }
}
