//
//  HText.swift
//  BookCore
//
//  Created by dominator on 11/05/20.
//

import SwiftUI

extension Text{
    init(highlightedText: String, alreadyTinted: Bool = false) {
        self = Text.getText(highlightedText, color: alreadyTinted ? Color(UIColor.label) : Color(UIColor.systemOrange))
    }
    private static func getText(_ string: String, color: Color) -> Text  {
        let textViews = string
            .components(
                separatedBy: .whitespaces
        ).map { str -> Text in
            if str.hasPrefix("`") && str.hasSuffix("`"){
                return Text(str
                    .dropFirst()
                    .dropLast())
                    .foregroundColor(color)
                    .bold()
            }else{
                return Text(str)
            }
        }
        guard textViews.count > 0 else {
            return Text("")
        }
        let first = textViews.first!
        let withoutFirst = textViews.dropFirst()
        return withoutFirst.reduce(first) { $0 + Text(" ") + $1 }
    }
}
