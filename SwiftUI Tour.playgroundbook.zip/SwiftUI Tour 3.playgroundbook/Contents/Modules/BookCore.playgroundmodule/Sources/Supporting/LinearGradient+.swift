//
//  LinearGradient+.swift
//  BookCore
//
//  Created by dominator on 09/05/20.
//

import SwiftUI

public extension LinearGradient{
    
    static let blueHue = LinearGradient(
        gradient: Gradient(
            colors: [
                .blueHueStart,
                .blueHueEnd
        ]),
        startPoint: .topLeading,
        endPoint: .bottomTrailing)
    
    static let redHue = LinearGradient(
    gradient: Gradient(
        colors: [
            .redHueStart,
            .redHueEnd
    ]),
    startPoint: .topLeading,
    endPoint: .bottomTrailing)
    
    func roundedRect(cornerRadius: CGFloat = 10)-> some View{
        RoundedRectangle(cornerRadius: cornerRadius)
            .fill(self)
    }
}
