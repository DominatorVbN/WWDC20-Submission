//
//  ErrorView.swift
//  BookCore
//
//  Created by dominator on 13/05/20.
//

import SwiftUI

struct ErrorView: View {
    let error: String
    var body: some View {
        VStack(spacing: 50){
            Image(systemName: "xmark.octagon.fill")
                .font(.largeTitle)
                .foregroundColor(.red)
            Text(error)
                .font(.title)
                .multilineTextAlignment(.center)
        }
    }
}

struct ErrorView_Previews: PreviewProvider {
    static var previews: some View {
        ErrorView(error: "Some Error")
    }
}
