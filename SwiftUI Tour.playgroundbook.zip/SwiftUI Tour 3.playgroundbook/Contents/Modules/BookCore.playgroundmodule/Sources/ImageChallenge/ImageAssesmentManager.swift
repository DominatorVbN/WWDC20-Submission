//
//  ImageAssesmentManager.swift
//  BookCore
//
//  Created by dominator on 13/05/20.
//

import SwiftUI
import PlaygroundSupport

public class ImageAssesmentManager: Assessable{
    public var remainingKey: String = "ImageAssesmentManagerRemainingKey"
    
    public var completedKey: String = "ImageAssesmentManagerCompletedKey"
    
    public var remaining: [ImageChallenge] = []
    
    public var completed: [ImageChallenge] = []
    
    private init() {
        setup()
    }
    
    public static let shared = ImageAssesmentManager()
    
    public func check(string: String) -> ImageChallenge? {
        for challenge in remaining{
            switch challenge {
            case .image:
                if string.contains("NamedImageProvider"){
                    return .image
                }
            case .imageLitral:
                if string.contains("UIImage"){
                    return .imageLitral
                }
            case .resizable:
                if string.contains("ResizableProvider"){
                    return .resizable
                }
            case .frame:
                if string.contains("FrameLayout"){
                    return .frame
                }
            case .fill:
                if string.contains("AspectRatioLayout"){
                    return .fill
                }
            case .clipshape:
                if string.contains("ClipEffect"){
                    return .clipshape
                }
            }
        }
        return nil
    }
    
    public func getAssesment() -> Result<SuccessModel, ErrorModel> {
        let remainingIsEmpty = remaining.isEmpty
        let isAllCompleted =  completed == ImageChallenge.allCases
        if remainingIsEmpty && isAllCompleted{
            let success = SuccessModel(conclusion: "## Tada!\n ### You now have created your own custom Avatar in SwiftUI 🥳.\n let's go ahead and put all your learning to work and create your own **WWDC** card with SwiftUI in [**next page**](@next)", hint: "You now have created your own custom Avatar in SwiftUI 🥳.", isCompleted: true)
            return .success(success)
        }
        let tuple = (completed.last!, remaining.first!)
        switch tuple {
        case (.image, .imageLitral):
            let success = SuccessModel(conclusion: "You can see an image of the road is rendered", hint: "Go ahead and replace `Image(\"road\")` with `Image(uiImage:)` and put an image literal from the suggestions then insert an image from your library.")
            return .success(success)
        case (.imageLitral, .resizable):
            let success = SuccessModel(conclusion: "That’s your image", hint: "Now let learn how can we resize the image, but images in SwiftUI are not resizable by default to resize them we have to first add `.resizable()` modifier below image.")
            return .success(success)
        case (.resizable, .fill):
            let success = SuccessModel(conclusion: "Is your `Image` distorted?", hint: "We can fix that by making our image to fill it's container. To do so, add `.scaledToFill()` modifier below the `.resizable()` modifier.")
            return .success(success)
        case (.fill, .frame):
            let success = SuccessModel(conclusion: "Now our `Image` is fiiled and resizable", hint: "Now we can change it's size as we want, add `.frame(width:200,height:200)` modifier below `.scaledToFill()` this will resize our image to 200x200.")
            return .success(success)
        case (.frame, .clipshape):
            let success = SuccessModel(conclusion: "So finally, the image is of your desired size", hint: "Now let's make it look like our avtar, add `.clipShape(Circle())` below `.frame(width:200,height:200)` which will make our image rounded.")
            return .success(success)
        default:
            let error = ErrorModel(error: "Oops! that doesn’t look like `\(ImageChallenge(rawValue: completed[completed.count - 2].rawValue + 1)!.text)`, make sure you typed it correctly and you write it in the correct order, then try running again!")
            return .failure(error)
        }
        
    }
    
    public func view<Content>(forResult: Result<SuccessModel, ErrorModel>, content: Content) -> AnyView where Content : View {
        AnyView(
            ImageInstructionView(
                result: forResult,
                content: content
            )
        )
    }
    
}
