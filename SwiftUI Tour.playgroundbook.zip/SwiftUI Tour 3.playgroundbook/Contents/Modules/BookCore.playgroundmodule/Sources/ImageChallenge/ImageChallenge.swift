//
//  ImageChallenge.swift
//  BookCore
//
//  Created by dominator on 13/05/20.
//

import PlaygroundSupport

public enum ImageChallenge: Int, CaseIterable, PlaygroundValueMappable{
    case image, imageLitral, resizable, fill, frame, clipshape
    public func map() -> PlaygroundValue {
        return .integer(self.rawValue)
    }
    
    public static func map<Type>(value: Type) -> ImageChallenge?{
        if Type.self == Int.self{
            return ImageChallenge(rawValue: value as! Int)
        }else{
            return nil
        }
    }
    
    public static func getAll() -> [ImageChallenge] {
        Self.allCases.sorted(by: { $0.rawValue < $1.rawValue})
    }
    
    var text: String{
        switch self {
        case .image:
            return ""
        case .imageLitral:
            return "Image(uiImage:)"
        case .resizable:
            return ".resizable()"
        case .frame:
            return ".frame(width:,height:)"
        case .fill:
            return ".scaledToFill()"
        case .clipshape:
            return ".scaledToFill()"
        }
    }
}
