//
//  ImageInstructionView.swift
//  BookCore
//
//  Created by dominator on 13/05/20.
//

import SwiftUI

struct ImageInstructionView<Content: View>: View {
    let result: Result<SuccessModel, ErrorModel>
    let content: Content
    @State var showHint = false
    var space: CGFloat{
        if case let .success(model) = result{
            if model.isCompleted{
                return 200
            }
        }
        return 0
    }
    var body: some View {
        VStack{
            getView()
                .padding()
            GeometryReader{ _ in
                self.content
                    .padding()
                    .padding(.bottom, self.space)
            }
            .clipped()
        }
        .animation(.default)
    }
    
    func getView()-> AnyView{
        let view: AnyView
        switch result {
        case .success(let model):
            view = AnyView(
                ZStack{
                    if model.isCompleted{
                        ConfetiView()
                    }
                    VStack(spacing: 25){
                        Text(highlightedText: model.isCompleted ? model.hint : model.conclusion , alreadyTinted: true)
                            .bold()
                            .font(.title)
                            .multilineTextAlignment(.center)
                            .foregroundColor(Color(UIColor.systemOrange))
                        if !model.hint.isEmpty && !model.isCompleted{
                            HStack{
                                if showHint{
                                    Text(highlightedText: model.hint)
                                        .multilineTextAlignment(.leading)
                                        .addBubbleBackground()
                                        .fixedSize(horizontal: false, vertical: true)
                                        .transition(.scale)
                                }
                            }
                            .onAppear {
                                withAnimation {
                                    self.showHint = true
                                }
                            }
                        }
                    }
            })
        case .failure(let error):
            view = AnyView(ErrorView(error: error.error))
        }
    return view
    }
}
