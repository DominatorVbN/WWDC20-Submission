//
//  WWDCCardAnimation.swift
//  BookCore
//
//  Created by dominator on 14/05/20.
//

import SwiftUI

public struct AlertInfo: Identifiable {
    public let id = UUID()
    public let title: String
    public let message: String?
    
    var alert: Alert{
        Alert(title: Text(title), message: message == nil ? nil : Text(message!), dismissButton: .default(Text("Ok")))
    }
}


public struct WWDCCardAnimation<Content: View>: View {
    
    @State var rotation: Angle = .degrees(0)
    @State var scale: CGFloat = 0
    @State var isShowingFire = true
    @State var isShowingButtons = false
    @State var shareSheet = false
    @State var rect: CGRect = .zero
    @State var alertInfo: AlertInfo?
    @Environment(\.hostingWindow) var hostingWindow
    let content: Content
    @State var image: UIImage? = nil
    public init(@ViewBuilder content: ()->Content){
        self.content = content()
    }
    
    var buttons: some View{
        HStack(spacing: 15){
            Spacer()
            Button(action: save) {
                HStack{
                    Text("Save")
                    Image(systemName: "photo")
                }
                .padding(.horizontal)
                .padding(.vertical, 8)
                .background(Color(UIColor.secondarySystemBackground))
                .clipShape(Capsule())
                .padding()
            }
            Button(action: share) {
                HStack{
                    Text("Share")
                    Image(systemName: "square.and.arrow.up")
                }
                .padding(.horizontal)
                .padding(.vertical, 8)
                .background(Color(UIColor.secondarySystemBackground))
                .clipShape(Capsule())
                .padding()
            }
            NavigationLink(destination:
                BadgeSceneView(image: getImage())
                    .edgesIgnoringSafeArea(.all)
                    .navigationBarTitle("Badge in 3D", displayMode: .inline)
            ) {
                HStack{
                    Text("View in")
                    Image(systemName: "view.3d")
                }
                .padding(.horizontal)
                .padding(.vertical, 8)
                .background(Color(UIColor.secondarySystemBackground))
                .clipShape(Capsule())
                .padding()
            }
            #if !targetEnvironment(macCatalyst)
            NavigationLink(destination:
                BadgeARSceneView(badgeImage: getImage())
                    .edgesIgnoringSafeArea(.all)
                    .navigationBarTitle("Badge in AR", displayMode: .inline)
            ) {
                HStack{
                    Text("View in")
                    Image(systemName: "arkit")
                }
                .padding(.horizontal)
                .padding(.vertical, 8)
                .background(Color(UIColor.secondarySystemBackground))
                .clipShape(Capsule())
                .padding()
            }
            #endif
            Spacer()
        }
    }
    
    public  var body: some View {
        NavigationView{
            ZStack{
                VStack{
                    Text("Here's your badge!")
                        .bold()
                        .font(.largeTitle)
                        .padding(.top)
                    GeometryReader{_ in
                        self.content
                            .background(RectGetter(rect: self.$rect))
                    }
                    .scaleEffect(self.scale)
                    .rotation3DEffect(self.rotation, axis: (x: 1, y: 1, z: 1))
                    .onAppear(perform: self.animate)
                    if self.isShowingButtons{
                        buttons
                            .accentColor(Color(UIColor.systemOrange))
                            .transition(.scale)
                    }else{
                        buttons
                            .hidden()
                    }
                }
                .padding(.top, 50)
                .padding(.bottom)
                if isShowingFire{
                    FireworkView()
                        .transition(.opacity)
                }
            }
            .edgesIgnoringSafeArea(.top)
            .navigationBarHidden(true)
            .alert(item: $alertInfo) { $0.alert }
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .sheet(isPresented: $shareSheet) {
            ShareSheet(activityItems: [self.getImage()])
        }
    }
    
    public func animate(){
        withAnimation(Animation.spring(response: 3, dampingFraction: 0.4, blendDuration: 0)) {
            self.scale = 1
        }
        withAnimation(Animation.easeInOut(duration: 3)) {
            self.rotation = .degrees(360+360)
        }
        Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { _ in
            withAnimation{
                self.isShowingFire = false
            }
        }
        Timer.scheduledTimer(withTimeInterval: 4, repeats: false) { _ in
            withAnimation {
                self.isShowingButtons = true
            }
        }
        Timer.scheduledTimer(withTimeInterval: 4.8, repeats: false) { _ in
            _ = self.getImage()
        }
    }
    
    func getImage()->UIImage{
        if let image = self.image{
            return image
        }else{
            let renderedImage = hostingWindow()!.rootViewController!.view.asImage(rect: rect)
            self.image = renderedImage
            return renderedImage
        }
    }
    
    func share(){
        shareSheet = true
    }
    
    func save(){
        ImageSaver().saveImageToLibrary(getImage()) { result in
            switch result{
            case .success:
                self.alertInfo = AlertInfo(title: "Success", message: "image have been save o your library!")
            case .error(let error):
                self.alertInfo = AlertInfo(title: "Unable to save image", message: error.localizedDescription)
            }
        }
    }
}
