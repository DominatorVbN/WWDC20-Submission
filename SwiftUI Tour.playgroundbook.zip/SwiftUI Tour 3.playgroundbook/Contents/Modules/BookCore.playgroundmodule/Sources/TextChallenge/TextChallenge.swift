//
//  TextChallenge.swift
//  BookCore
//
//  Created by dominator on 11/05/20.
//

import PlaygroundSupport

public enum TextChallenge: Int,CaseIterable, PlaygroundValueMappable{
    public func map() -> PlaygroundValue {
        return .integer(self.rawValue)
    }
    
    public static func map<Type>(value: Type) -> TextChallenge?{
        if Type.self == Int.self{
            return TextChallenge(rawValue: value as! Int)
        }else{
            return nil
        }
    }
    
    public static func getAll() -> [TextChallenge] {
        Self.allCases.sorted(by: { $0.rawValue < $1.rawValue})
    }
    
    case text = 0, font, color, bold
}
