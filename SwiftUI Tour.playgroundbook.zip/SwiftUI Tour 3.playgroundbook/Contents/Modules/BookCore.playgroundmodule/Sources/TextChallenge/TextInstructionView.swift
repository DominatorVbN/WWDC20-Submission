//
//  TextInstructionView.swift
//  BookCore
//
//  Created by dominator on 11/05/20.
//

import SwiftUI

public struct TextInstructionView<Content: View>: View {
    public let conclusion: String
    public let hint: String
    public let isCompleted: Bool
    public let error: String?
    public let content: Content
    
    @State var showHint = false
    
    public init(result: Result<SuccessModel,ErrorModel>,content: Content){
        self.content = content
        switch result {
        case .success(let model):
            self.conclusion = model.conclusion
            self.hint = model.hint
            self.error = nil
            self.isCompleted = model.isCompleted
        case .failure(let error):
            self.error = error.error
            self.conclusion = ""
            self.hint = ""
            self.isCompleted = false
        }
    }
    
    public var body: some View {
        ZStack{
            VStack{
                VStack(spacing: 25){
                    if error != nil{
                        ErrorView(error: error!)
                    }else{
                        Text(isCompleted ? hint : conclusion)
                            .bold()
                            .font(.title)
                            .multilineTextAlignment(.center)
                            .foregroundColor(Color(UIColor.systemOrange))
                            .padding(.horizontal)

                        if !hint.isEmpty && !isCompleted{
                            
                            HStack{
                                if showHint{
                                    Text(highlightedText: hint)
                                        .multilineTextAlignment(.leading)
                                        .addBubbleBackground()
                                        .fixedSize(horizontal: false, vertical: true)
                                        .fixedSize(horizontal: false, vertical: true)
                                        .transition(.scale)
                                }
                            }
                            .onAppear {
                                withAnimation {
                                    self.showHint = true
                                }
                            }
                        }
                    }
                }
                .padding()
                .animation(.default)
                GeometryReader{ geo in
                    self.content
                }
            }
            if isCompleted{
                ConfetiView()
            }
        }
    }
}

