//
//  TextAssesmentManager.swift
//  BookCore
//
//  Created by dominator on 11/05/20.
//

import PlaygroundSupport
import SwiftUI

public class TextAssessmentManager: Assessable{
    
    public var remainingKey: String = "TextAssessmentManagerRemainingKey"
    public var completedKey: String = "TextAssessmentManagerCompletedKey"
    public var remaining: [TextChallenge] = []
    public var completed: [TextChallenge] = []
    
    public static var shared = TextAssessmentManager()

    
    private init() {
        setup()
    }
    
    public func check(string: String) -> TextChallenge? {
        for challenge in remaining{
            switch challenge {
            case .text:
                if string.contains("Text"){
                    return .text
                }
            case .font:
                if string.contains("Text") && string.contains("SwiftUI.Text.Modifier.font"){
                    return .font
                }
            case .color:
                if string.contains("Text") && string.contains("SwiftUI.Text.Modifier.color"){
                    return .color
                }
            case .bold:
                if string.contains("Text") && string.contains("SwiftUI.BoldTextModifier"){
                    return .bold
                }
            }
        }
        return nil
    }
    
    public func getAssesment() -> Result<SuccessModel, ErrorModel> {
        let remainingIsEmpty = remaining.isEmpty
        let isAllCompleted =  completed == TextChallenge.allCases
        if remainingIsEmpty && isAllCompleted{
            let success = SuccessModel(conclusion: "## Tada!\n ### That complete the **Hello World** in **SwiftUI**\n Let's go ahead and learn some more exciting stuff on [**next page**](@next)", hint: "You now have created your own custom text in SwiftUI wasn’t it easy 🥳", isCompleted: true)
            return .success(success)
        }
        let tuple = (completed.last!, remaining.first!)
        switch tuple{
        case (.text, .font):
            let success = SuccessModel(
                conclusion: "You have taken the first step towards awesomeness.",
                hint: "Now let’s customize of TextView a bit, add  `.font(.title)` modifier below Text then hit \"Run My Code\".")
            return .success(success)
        case (.font, .color):
            let success = SuccessModel(
                conclusion: "You can see the change in the size of the text.",
                hint: "To customize a SwiftUI view, you call methods called modifiers. The `.font(.title)` you written is also a modifier. Now let’s change the colour of our text, add another modifier `.foregroundColor(.green)` below `.font(.title)` then hit \"Run My Code\")")
            return .success(success)
        case (.color, .bold):
            let success = SuccessModel(
                conclusion: "So now we have a colored text.",
                hint: "Thinking how to make the text bold? To do that add `.bold()` below `.foregroundColor(.green)` then hit \"Run My Code\"")
            return .success(success)
        default:
            let error = ErrorModel(error: "Oops! that doesn’t look like `\(getModifierText(for: TextChallenge(rawValue: completed[completed.count - 2].rawValue + 1)!))`, make sure you typed it correctly, then try running again!")
            return .failure(error)
        }
    }
    
    func getModifierText(for challenge: TextChallenge) -> String{
        switch challenge {
        case .text:
            return ""
        case .color:
            return ".foregroundColor(Color.green)"
        case .font:
            return ".font(.title)"
        case .bold:
            return ".bold()"
        }
    }
        
    public func view<Content>(forResult: Result<SuccessModel, ErrorModel>, content: Content) -> AnyView where Content : View {
        return AnyView(TextInstructionView(result: forResult, content: content))
    }
}
