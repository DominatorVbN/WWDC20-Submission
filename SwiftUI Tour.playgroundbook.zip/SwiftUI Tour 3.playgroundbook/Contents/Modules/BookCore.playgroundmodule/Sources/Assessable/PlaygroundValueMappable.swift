//
//  PlaygroundValueMappable.swift
//  BookCore
//
//  Created by dominator on 12/05/20.
//

import PlaygroundSupport

public protocol PlaygroundValueMappable: Equatable {
    func map() -> PlaygroundValue
    static func map<Type>(value: Type) -> Self?
    static func getAll() -> [Self]
}
