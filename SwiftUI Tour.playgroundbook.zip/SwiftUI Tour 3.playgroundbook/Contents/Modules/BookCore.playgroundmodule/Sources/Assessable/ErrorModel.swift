//
//  ErrorModel.swift
//  BookCore
//
//  Created by dominator on 12/05/20.
//

import Foundation

public struct ErrorModel: Error {
    let error: String
}
