//
//  SuccessModel.swift
//  BookCore
//
//  Created by dominator on 12/05/20.
//

import Foundation

public struct SuccessModel{
    let conclusion: String
    let hint: String
    let isCompleted: Bool
    init(conclusion: String, hint: String, isCompleted: Bool = false) {
        self.conclusion = conclusion
        self.hint = hint
        self.isCompleted = isCompleted
    }
}
