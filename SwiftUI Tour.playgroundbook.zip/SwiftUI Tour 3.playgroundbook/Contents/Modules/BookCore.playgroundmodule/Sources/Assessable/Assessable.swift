//
//  Assessable.swift
//  BookCore
//
//  Created by dominator on 12/05/20.
//

import PlaygroundSupport
import SwiftUI

public protocol Assessable: class {
    associatedtype Challenge
    var remainingKey: String { get }
    var completedKey: String { get }
    var remainingStore: [Challenge]? { get set }
    var completedStore: [Challenge]? { get set }
    var remaining: [Challenge] { get set }
    var completed: [Challenge] { get set }
    func showResult<Content: View>(@ViewBuilder content: ()->Content)
    func check(string: String) -> Challenge?
    func getAssesment() -> Result<SuccessModel, ErrorModel>
    func showHint(result: Result<SuccessModel, ErrorModel>)
    func view<Content: View>(forResult: Result<SuccessModel, ErrorModel>, content: Content) -> AnyView
    func setup()
}

public extension Assessable where Challenge: PlaygroundValueMappable{

    var remainingStore: [Challenge]?{
        get{
            if case let .array(array) = PlaygroundKeyValueStore.current[remainingKey]{
                return array
                    .map{
                        if case let .integer(value) = $0 {
                            return Challenge.map(value: value)
                        }else {
                            return nil
                        }
                }.compactMap { $0 }
            }
            return nil
        }
        set{
            guard let values = newValue else {
                PlaygroundKeyValueStore.current[remainingKey] = nil
                return
            }
            let array = values.map{ $0.map() }
            PlaygroundKeyValueStore.current[remainingKey] = .array(array)
        }
    }
    
    var completedStore: [Challenge]?{
        get{
            if case let .array(array) = PlaygroundKeyValueStore.current[completedKey]{
                return array
                    .map{
                        if case let .integer(value) = $0 {
                            return Challenge.map(value: value)
                        }else {
                            return nil
                        }
                }.compactMap { $0 }
            }
            return nil
        }
        set{
            guard let values = newValue else {
                PlaygroundKeyValueStore.current[remainingKey] = nil
                return
            }
            let array = values.map{ $0.map() }
            PlaygroundKeyValueStore.current[completedKey] = .array(array)
        }
    }
    

    
    func setup() {
        self.remaining = Challenge.getAll()
        self.completed = []
        
        if let persitedRemaining = remainingStore {
            self.remaining = persitedRemaining
        }
        
        if let persitedCompleted = completedStore{
            self.completed = persitedCompleted
        }
    }
    
    
    func showResult<Content: View>(@ViewBuilder content: ()->Content){
        let content = content()
        if let challenge = check(string: String(describing: content.body.self)){
            if let remainingIndex = remaining.firstIndex(of: challenge){
                remaining.remove(at: remainingIndex)
                if let completedIndex = completed.firstIndex(of: challenge){
                    completed.remove(at: completedIndex)
                }
                completed.append(challenge)
            }
        }
        let result = getAssesment()
        showHint(result: result)
        switch result {
        case .success(let model):
            self.remainingStore = remaining
            self.completedStore = completed
            if model.isCompleted{
               self.remainingStore = nil
                self.completedStore = nil
            }
        default:
            break
        }
        PlaygroundPage.current.setLiveView(view(forResult: result, content: content))
    }
    
    func showHint(result: Result<SuccessModel, ErrorModel>) {
        switch result{
        case .success(let model):
            if model.isCompleted{
                PlaygroundPage.current.assessmentStatus = .pass(message: model.conclusion)
            }
        case .failure(let error):
            PlaygroundPage.current.assessmentStatus = .fail(hints: [error.error], solution: nil)
        }
    }
}
