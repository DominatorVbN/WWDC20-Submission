//
//  StackAssesmentManager.swift
//  BookCore
//
//  Created by dominator on 09/05/20.
//

import SwiftUI
import PlaygroundSupport

public class StackAssesmentManager: Assessable{
    public var remainingKey: String = "StackManagerRemainingKey"
    public var completedKey: String = "StackManagerCompletedKey"
    public var remaining: [StackChallenge] = []
    public var completed: [StackChallenge] = []
    
    public static let shared = StackAssesmentManager()
    
    private init(){
        setup()
    }
    
    public func check(string: String) -> StackChallenge? {
        if string.contains("spacing: Optional("){
            return assesSpacingStack(string)
        }else{
            return assesStacks(string)
        }
    }
    
    func assesSpacingStack(_ string: String) -> StackChallenge?{
        if string.contains("VStack<TupleView"){
            return .VStackWithSpacing
        }else if string.contains("HStack<TupleView"){
            return .HStackWithSpacing
        }
        return nil
    }
    
    func assesStacks(_ string: String) -> StackChallenge?{
        if string.contains("VStack<TupleView"){
            return .VStack
        }else if string.contains("HStack<TupleView"){
            return .HStack
        }else if string.contains("ZStack<TupleView"){
            return .ZStack
        }
        return nil
    }
    
    public func getAssesment() -> Result<SuccessModel, ErrorModel> {
        let remainingIsEmpty = remaining.isEmpty
        let isAllCompleted =  completed == StackChallenge.allCases
        if remainingIsEmpty && isAllCompleted{
            let success = SuccessModel(conclusion: "## You did it!🎉!\n ### You might have understood how the Stacks work in SwiftUI.👨‍💻\n You must be wondering why there is no spacing for `ZStack`? Well, that stack does not have any space property cause it's not logical having space in `Z` coordinate.\nlet's go ahead and learn some more exciting stuff on [**next page**](@next)", hint: "Congrats!🎉\nYou might have now understood how the Stacks work in SwiftUI.", isCompleted: true)
            return .success(success)
        }
        
        let tuple = (completed.last!, remaining.first!)
        switch tuple{
        case (.VStack, .HStack):
            let success = SuccessModel(
                conclusion: "As you can see the second text has been rendered below the first one",
                hint: "Now that you can arrange text vertically let’s try arranging them horizontally, to do that replace `VStack` with `HStack` .")
            return .success(success)
        case (.HStack, .ZStack):
            let success = SuccessModel(
                conclusion: "The text are rendered one after another just as you would have expected.",
                hint: "Let's try the last `Stack` on the list, replace `HStack` with `ZStack` .")
            return .success(success)
        case (.ZStack, .VStackWithSpacing):
            let success = SuccessModel(
                conclusion: "Aah! it’s all mixed up 🥴, but it is the exact right text is rendered on top of another back to front.",
                hint: "Now you have learned how to arrange multiple views in `SwiftUI` , but you might want some spacing between them, replace  `ZStack` with `VStack(spacing:50)` .")
            return .success(success)
        case (.VStackWithSpacing, .HStackWithSpacing):
            let success = SuccessModel(
                conclusion: "👽 Space between us or rather space between views.",
                hint: "Let’s try adding space horizontally too, replace `VStack(spacing:50)` with `HStack(spacing:50)` . ")
            return .success(success)
        default:
            let error = ErrorModel(error: "Oops! that doesn’t look like `\(StackChallenge(rawValue: completed[completed.count - 2].rawValue + 1)!.text)`, make sure you typed it correctly, then try running again!")
            return .failure(error)
        }
    }
    
    public func view<Content>(forResult: Result<SuccessModel, ErrorModel>, content: Content) -> AnyView where Content : View {
        AnyView(
            StackAnimation(
                result: forResult,
                lastCompleted: completed.last!,
                content: content
            )
        )
    }
}
