//
//  StackChallenge.swift
//  BookCore
//
//  Created by dominator on 11/05/20.
//

import Foundation
import PlaygroundSupport

public enum StackChallenge: Int, CaseIterable, PlaygroundValueMappable{
    
    public func map() -> PlaygroundValue {
        return .integer(self.rawValue)
    }
    
    public static func map<Type>(value: Type) -> StackChallenge?{
        if Type.self == Int.self{
            return StackChallenge(rawValue: value as! Int)
        }else{
            return nil
        }
    }
    
    public static func getAll() -> [StackChallenge] {
        Self.allCases.sorted(by: { $0.rawValue < $1.rawValue})
    }
    
    case VStack = 0, HStack, ZStack, VStackWithSpacing, HStackWithSpacing
    
    public var index: Int{
        StackChallenge.allCases.firstIndex(of: self)!
    }
    
    public var text: String{
        switch self {
        case .VStack:
            return "VStack"
        case .HStack:
            return  "HStack"
        case .ZStack:
            return "ZStack"
        case .VStackWithSpacing:
            return "VStack(spacing:50)"
        case .HStackWithSpacing:
            return "HStack(spacing:50)"
        }
    }
}
