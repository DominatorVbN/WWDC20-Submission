//
//  StackIntroView.swift
//  BookCore
//
//  Created by dominator on 11/05/20.
//

import SwiftUI

struct StackIllustrationView: View {
    let colors: [[Color]] = [[Color(#colorLiteral(red: 0.2285425961, green: 0.5784165859, blue: 0.6895257831, alpha: 1)), Color(#colorLiteral(red: 0.4271130264, green: 0.8364676833, blue: 0.9309514165, alpha: 1))],[ Color(#colorLiteral(red: 0.7387117147, green: 0.3052827716, blue: 0.6135740876, alpha: 1)), Color(#colorLiteral(red: 0.9282850623, green: 0.2315128148, blue: 0.3473922014, alpha: 1))]]
    
    @State var offset:CGFloat = 300
    @State var showV = false
    @State var showH = false
    @State var showZ = false
    var body: some View {
        ZStack{
            VStack(spacing: 50) {
                Text("Arranging Views using Stacks")
                    .bold()
                    .font(.largeTitle)
                    .foregroundColor(Color(UIColor.systemOrange))
                if showV{
                    Text("VStack")
                        .font(.title)
                        .transition(.scale)
                }
                if showH{
                    Text("HStack")
                        .font(.title)
                        .transition(.scale)
                }
                if showZ{
                    Text("ZStack")
                        .font(.title)
                        .transition(.scale)
                }
                ZStack(alignment: .topLeading){
                    HStack {
                        VStack{
                            getRect(index: 0)
                            
                            if showV{
                                getRect(index: 1)
                                    .transition(.scale)
                            }
                        }
                        
                        if showH{
                            getRect(index: 1)
                                .transition(.scale)
                        }
                    }
                    if showZ{
                        RoundedRectangle(cornerRadius: 10)
                            .fill(LinearGradient(gradient: Gradient(colors: colors[1]), startPoint: .leading, endPoint: .trailing))
                            .frame(width: 40, height: 40)
                            .transition(.scale)
                    }
                }
            }
            .scaleEffect(1-(offset/300))
            .animation(.spring())
            .onAppear(perform: animate)
            .transition(.scale)
        }
        .animation(.default)
    }
    
    func getRect(index: Int) -> some View{
        return RoundedRectangle(cornerRadius: 10)
            .fill(LinearGradient(gradient: Gradient(colors: colors[index]), startPoint: .leading, endPoint: .trailing))
            .frame(width: 100, height: 100)
    }
    
    func animate(){
        self.offset = 0
        Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { _ in
            self.showV = true
            Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { _ in
                self.showV = false
                Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { _ in
                    self.showH = true
                    Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { _ in
                        self.showH = false
                        Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { _ in
                            self.showZ = true
                            Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { _ in
                                self.showZ = false
                                self.offset = 300
                                self.animate()
                            }
                        }
                    }
                }
            }
        }
    }
}
