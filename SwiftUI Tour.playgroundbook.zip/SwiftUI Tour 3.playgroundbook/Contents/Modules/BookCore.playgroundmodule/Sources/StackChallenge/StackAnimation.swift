//
//  StackAnimation.swift
//  BookCore
//
//  Created by dominator on 10/05/20.
//


import SwiftUI

public struct StackAnimation<Content: View>: View{
    let conclusion: String
    let hint: String
    let error: String?
    let state: StackChallenge
    let isCompleted: Bool
    let content: Content
    
    @State var showingFirst = false
    @State var showingSecond = false
    @State var spacing: CGFloat = 8
    @State var showHint = false
    
    public var spacingString: String{
        String(Int(spacing))
    }
    
    public var stackText: String{
        switch state {
        case .VStack:
            return "VStack"
        case .HStack:
            return "HStack"
        case .ZStack:
            return "ZStack"
        case .VStackWithSpacing:
            return "VStack(spacing: \(spacingString))"
        case .HStackWithSpacing:
            return "HStack(spacing: \(spacingString))"
        }
    }
    
    public var rects: some View{
        Group{
            if self.showingFirst{
                LinearGradient.blueHue.roundedRect()
                    .frame(width: 100, height: 100)
                    .transition(.scale)
            }
            if self.showingSecond{
                if state == .ZStack{
                    LinearGradient.redHue.roundedRect()
                        .frame(width: 50, height: 50)
                        .transition(.scale)
                }else{
                    LinearGradient.redHue.roundedRect()
                        .frame(width: 100, height: 100)
                        .transition(.scale)
                }
            }
        }
    }
    
    public var stackAnimation: some View{
        ZStack{
            if isCompleted{
                ConfetiView()
            }
            ZStack(alignment: .top){
                VStack(spacing: 25){
                    if error != nil{
                        ErrorView(error: error!)
                    }else{
                        Text(highlightedText: isCompleted ? hint : conclusion , alreadyTinted:true)
                            .bold()
                            .font(.title)
                            .multilineTextAlignment(.center)
                            .foregroundColor(Color(UIColor.systemOrange))
                            .layoutPriority(1)
                        if !hint.isEmpty && !isCompleted{
                            HStack{
                                if showHint{
                                    Text(highlightedText: hint)
                                        .multilineTextAlignment(.leading)
                                        .addBubbleBackground()
                                        .fixedSize(horizontal: false, vertical: true)
                                        .transition(.scale)
                                }
                            }
                            .onAppear {
                                withAnimation {
                                    self.showHint = true
                                }
                            }
                        }
                        Text(stackText)
                            .bold()
                            .font(.title)
                            .foregroundColor(Color(UIColor.systemOrange))
                            .animation(nil)
                    }
                }
                Group{
                    if self.state == .VStack{
                        VStack{ self.rects }
                    }else if self.state == .HStack{
                        HStack{ self.rects }
                    }else if self.state == .ZStack{
                        ZStack{ self.rects }
                    }else if self.state == .VStackWithSpacing{
                        VStack(spacing: self.spacing){ self.rects }
                    }else if self.state == .HStackWithSpacing{
                        HStack(spacing: self.spacing){ self.rects }
                    }
                }
                .animation(.default)
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
                .padding(.top, 250 + (self.state == .VStackWithSpacing ? (spacing/2) : 0))
            }
            .padding()
        }
        .onAppear(perform: self.animate)
    }
    
    public var body: some View{
        VStack{
            stackAnimation
            GeometryReader{ _ in
                self.content
            }
        }
    }
    
    public init(result: Result<SuccessModel, ErrorModel>, lastCompleted: StackChallenge, content: Content) {
        self.content = content
        switch result {
        case .success(let model):
            self.conclusion = model.conclusion
            self.hint = model.hint
            self.state = lastCompleted
            self.isCompleted = model.isCompleted
            self.error = nil
        case .failure(let error):
            self.conclusion = ""
            self.hint = ""
            self.state = lastCompleted
            self.isCompleted = false
            self.error = error.error
        }

    }
    
    func animate(){
        if state == .VStackWithSpacing || state == .HStackWithSpacing{
            Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
                self.showingFirst = true
                self.showingSecond = true
                Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
                    self.spacing = 50
                    Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
                        self.spacing = 8
                        Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
                            self.showingFirst = false
                            self.showingSecond = false
                            self.animate()
                        }
                    }
                }
            }
        }else{
            Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
                self.showingFirst = true
                Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
                    self.showingSecond = true
                    Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
                        self.showingSecond = false
                        Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
                            self.showingFirst = false
                            self.animate()
                        }
                    }
                }
            }
        }
    }
}
