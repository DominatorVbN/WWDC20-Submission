//
//  BadgeARSceneView.swift
//  BookCore
//
//  Created by dominator on 17/05/20.
//
#if !targetEnvironment(macCatalyst)

import SwiftUI
import UIKit
import ARKit
import SceneKit
import Combine

struct BadgeARView: UIViewRepresentable {
    let badgeImage: UIImage
    @Binding var isPlaneDetected: Bool
    @Binding var firstBadgePlaced: Bool
    @Binding var cardCount: Int
    @State var previousCardCount = 0
    class Coordinator: NSObject, ARSCNViewDelegate{
        let parent: BadgeARView
        init(parent: BadgeARView) {
            self.parent = parent
        }
        
        func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
            // Ignore all anchors except for planes
            guard let planeAnchor = anchor as? ARPlaneAnchor else { return }
            // Create the plane to visualize the node using its position and extent
            let plane = SCNPlane(width: CGFloat(planeAnchor.extent.x), height: CGFloat(planeAnchor.extent.z))
            plane.firstMaterial?.fillMode = .lines
            let planeNode = SCNNode(geometry: plane)
            //            planeNode.isHidden = true
            planeNode.position = SCNVector3Make(planeAnchor.center.x, 0, planeAnchor.center.z)
            // Rotate the planeNode to a horizontal position
            planeNode.transform = SCNMatrix4MakeRotation(-Float.pi / 2, 1, 0, 0)
            // Add the planeNode to ARKit's root node
            node.addChildNode(planeNode)
            parent.isPlaneDetected = true
        }
        
        func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
            // Ignore all anchors except for planes
            guard let planeAnchor = anchor as? ARPlaneAnchor,
                // Get the associated planeNode with its plane child
                let planeNode = node.childNodes.first,
                let plane = planeNode.geometry as? SCNPlane else { return }
            // Update planeNode's position
            planeNode.position = SCNVector3(
                CGFloat(planeAnchor.center.x), 0, CGFloat(planeAnchor.center.z)
            )
            // Update plane's size
            plane.width = CGFloat(planeAnchor.extent.x)
            plane.height = CGFloat(planeAnchor.extent.z)
        }
    }
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    func makeUIView(context: UIViewRepresentableContext<BadgeARView>) -> ARSCNView {
        isPlaneDetected = false
        firstBadgePlaced = false
        let sceneView = ARSCNView(frame: .zero)
        sceneView.delegate = context.coordinator
        sceneView.autoenablesDefaultLighting = true
        sceneView.automaticallyUpdatesLighting = true
        let scene = SCNScene()
        sceneView.scene = scene
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = .horizontal
        sceneView.session.run(config, options: [])
        
        return sceneView
    }
    
    func updateUIView(_ uiView: ARSCNView, context: UIViewRepresentableContext<BadgeARView>) {
        if previousCardCount != cardCount{
            self.placeCard(on: uiView)
        }
        for node in uiView.scene.rootNode.childNodes where node.name == "badge"{
            node.geometry?.materials.first?.diffuse.contents = badgeImage
        }
    }
    
    func placeCard(on sceneView: ARSCNView) {
        // Do a hit test for the center of the viewport
        let hitTestResults = sceneView.hitTest(sceneView.center, types: .existingPlaneUsingExtent)
        // Check whether there was a hit
        guard let hitTestResult = hitTestResults.first else {
            return
        }
        // Compute the needed translation
        let transform = hitTestResult.worldTransform
        var translate: SIMD3<Float> {
            let delta = transform.columns.3
            return SIMD3(delta.x, delta.y, delta.z)
        }
        // Create the cardNode
        let height: CGFloat = 0.15
        let scaleFactor = height / badgeImage.size.height
        let width = badgeImage.size.width * scaleFactor
        let badge = SCNPlane(width: width, height: height)
        badge.cornerRadius = 5 * scaleFactor
        badge.materials.first?.diffuse.contents = badgeImage
        badge.materials.first?.lightingModel = .constant
        let badgeNode = SCNNode(geometry: badge)
        badgeNode.name = "badge"
        badgeNode.position = SCNVector3(translate.x, translate.y, translate.z)
        // Rotate the planeNode around x to a horizontal position and around y to face the camera
        guard let currentFrame = sceneView.session.currentFrame else { return }
        badgeNode.eulerAngles = SCNVector3(-Float.pi / 2, currentFrame.camera.eulerAngles.y, 0)
        
        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light!.type = .ambient
        ambientLightNode.light!.color = UIColor.lightGray
        badgeNode.addChildNode(ambientLightNode)
        // Add it to the composition
        sceneView.scene.rootNode.addChildNode(badgeNode)
        firstBadgePlaced = true
    }
}

struct BadgeARSceneView: View {
    let badgeImage: UIImage
    @State var isPlaneDetected: Bool = false
    @State var firstBadgePlaced: Bool = false
    @State var cardCount = 0
    let addAction = PassthroughSubject<Void, Never>()
    var body: some View{
        ZStack{
            BadgeARView(badgeImage: badgeImage, isPlaneDetected: $isPlaneDetected, firstBadgePlaced: $firstBadgePlaced,cardCount: $cardCount)
            VStack(spacing: 20){
                Spacer()
                if self.cardCount == 0 || !isPlaneDetected{
                    Text(highlightedText: !isPlaneDetected ? "Find an even surface to place your `badge` and hover over it." : "Great! Now tap \"Add my badge\".")
                        .multilineTextAlignment(.leading)
                        .addBubbleBackground()
                        .fixedSize(horizontal: false, vertical: true)
                        .transition(.scale)
                }
                if isPlaneDetected{
                    Button(action: {
                        self.cardCount += 1
                    }) {
                        Text("Add my badge")
                            .foregroundColor(.white)
                            .padding(.horizontal)
                            .padding(.vertical, 10)
                            .background(
                                Capsule()
                                    .fill(
                                        Color(UIColor.systemOrange)
                                )
                        )
                    }
                    .transition(.scale)
                }
            }
            .padding(.bottom, 80)
        }
    }
}

#endif
