//
//  CardSceneView.swift
//  BookCore
//
//  Created by dominator on 14/05/20.
//

import SwiftUI
import SceneKit

public struct BadgeSceneView: UIViewRepresentable {
    let image: UIImage
    public init(image: UIImage){
        self.image = image
    }
    public func makeUIView(context: UIViewRepresentableContext<BadgeSceneView>) -> SCNView {
        
        let scnView = SCNView(frame: .zero)
        
        // create a new scene
        let scene = SCNScene(named: "art.scnassets/ribbon.scn")!
        
        // create and add a camera to the scene
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        scene.rootNode.addChildNode(cameraNode)
        
        // place the camera
        cameraNode.position = SCNVector3(x: 0, y: 0, z: 15)
        
        // create and add a light to the scene
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light!.type = .omni
        lightNode.position = SCNVector3(x: 0, y: 10, z: 10)
        scene.rootNode.addChildNode(lightNode)
        
        // create and add an ambient light to the scene
        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light!.type = .ambient
        ambientLightNode.light!.color = UIColor.darkGray
        scene.rootNode.addChildNode(ambientLightNode)
        
        // retrieve the badge node
        let badge = scene.rootNode.childNode(withName: "badge", recursively: true)!
        
        let card = badge.childNode(withName: "Card", recursively: true)!
        card.geometry?.materials.first?.diffuse.contents = image

        
        
        // set the scene to the view
        scnView.scene = scene
        
        // allows the user to manipulate the camera
        scnView.allowsCameraControl = true
        
        
        // configure the view
        scnView.backgroundColor = UIColor.clear
        
        return scnView
    }
    
    public func updateUIView(_ uiView: SCNView, context: UIViewRepresentableContext<BadgeSceneView>) { }
}
