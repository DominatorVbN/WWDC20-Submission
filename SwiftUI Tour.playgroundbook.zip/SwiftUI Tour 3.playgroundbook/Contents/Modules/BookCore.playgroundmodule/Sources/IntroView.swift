//
//  LiveView.swift
//  BookCore
//
//  Created by dominator on 08/05/20.
//

import UIKit
import SwiftUI

extension View {
    public func foreground<Overlay: View>(_ overlay: Overlay) -> some View {
        self.overlay(overlay).mask(self)
    }
}

struct IntroView: View {
    @State var offset: CGFloat = 300
    var body: some View{
        VStack(spacing: 50){
            Image("swiftui")
                .resizable()
                .frame(width: 150, height: 150)
                .blur(radius: offset/3)
                .scaleEffect(1-(offset/300))
                .shadow(color: .darkBlue, radius: 20, x: 0, y: 10)
            HStack(alignment: .lastTextBaseline){
                Text("Welcome to")
                    Text("SwiftUI")
                        .bold()
                        .foreground(
                            LinearGradient(
                                gradient: Gradient(colors: [.lightBlue,.darkBlue]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                    )
                Text("Playground")
            }
            .scaleEffect(1-(offset/300))
            .offset(CGSize(width: 0, height: offset))
            .blur(radius: offset/3)
            .font(.largeTitle)
            .onAppear {
                withAnimation(.spring(response: 1.5, dampingFraction: 0.7, blendDuration: 0.3)) {
                    self.offset = 0
                }
        }
        }
    }
}

struct LiveView_Previews: PreviewProvider {
    static var previews: some View {
        IntroView()
    }
}
