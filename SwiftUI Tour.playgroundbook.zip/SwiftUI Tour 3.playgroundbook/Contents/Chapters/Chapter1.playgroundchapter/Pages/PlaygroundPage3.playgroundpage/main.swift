/*:
 # 🌄 Images in SwiftUI

 It this page we are going to learn how to add **Image** in your **SwiftUI** views.
 we are going to learn how to create a custom image view, resize it, and creating an avatar image for showing our own image.
 
 **Image** has multiple initializers for creating images from different sources.
 we are gonna use `Image(_:)` for loading images that are already shipped with this playground and `Image(uiImage: )` with the conjunction of Image Literal to get image from our photo library.
 
 ## So let's get started
 
 The code below creates an image of a road. Hit **"Run My Code"** to see the image rendered on the right.

 > The **road** image is already included with the playground and been taken from [here](https://pixabay.com/photos/hitcher-by-hitch-hiking-road-man-1536748/). Don't add modifiers just now, look out for instruction on the right.
 */
import SwiftUI

struct ContentView: View {
    var body: some View {
        /*#-editable-code*/Image("road")/*#-end-editable-code*/
        //#-editable-code Tap to add modifiers
        //#-end-editable-code
    }
}

//#-hidden-code
ImageAssesmentManager.shared.showResult {
    ContentView()
}
//#-end-hidden-code
