import BookCore
import PlaygroundSupport

PlaygroundPage.current.setLiveView(getStackIllustrationView())

