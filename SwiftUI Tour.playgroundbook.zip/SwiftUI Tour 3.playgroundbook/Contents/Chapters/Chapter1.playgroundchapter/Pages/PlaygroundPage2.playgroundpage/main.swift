/*:
 # 📚 Stacks in SwiftUI
 
 In **SwiftUI** when we want to arrange two or more views, we use stacks, which groups and arranges our views vertically, horizontally, and back-to-front.
 
 ### SwiftUI provides us three types of stacks to arrange our view according to our requirement, they are:
 1. `VStack`: to arrange views one below other vertically
 2. `HStack`: to arrange views one after another from left to right horizontally
 3. `ZStack`: for arranging views back-to-front in `Z` axis.
 
 > Check the animation on the right to see how stack arranges the views.
 
 ## Lets stack some texts!
 To understand the stacks we will use them to group some `Text` views.
 Add a TextView below the first one to place the new text right below it.
 */
import SwiftUI

struct ContentView: View {
    var body: some View {
        /*#-editable-code VStack*/VStack/*#-end-editable-code*/ {
            Text("First Text")
            Text(/*#-editable-code Tap to add text*/""/*#-end-editable-code*/)
        }
    }
}
//: When you're ready, hit "Run My Code" to see the result.
//: > Lookout for the instructions on the right.
//#-hidden-code
StackAssesmentManager.shared.showResult {
    ContentView()
}
//#-end-hidden-code

