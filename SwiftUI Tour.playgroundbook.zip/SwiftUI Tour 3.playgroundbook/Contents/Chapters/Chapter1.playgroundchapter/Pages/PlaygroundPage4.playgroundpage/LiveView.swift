
import SwiftUI
import PlaygroundSupport

struct CardBackgroundView: View {
    let color: UIColor
    var body: some View{
        Image("cardmask")
            .renderingMode(.template)
            .resizable()
            .scaledToFit()
            .foregroundColor(Color(color))
    }
}

struct CardForegroundView: View {
    let name: String
    let role: String
    let image: UIImage
    var body: some View{
        GeometryReader{ geometry in
            VStack{
                Image(uiImage: self.image)
                    .resizable()
                    .scaledToFill()
                    .frame(width: geometry.size.width/3, height: geometry.size.width/3)
                    .clipShape(Circle())
                    .overlay(
                        Circle().stroke(Color(UIColor.label), lineWidth: 8))
                Text(self.name)
                    .bold()
                    .font(.system(size: geometry.size.height * 0.1))
                    .frame(minWidth: 0, maxWidth: .infinity)
                    .layoutPriority(1)
                Text(self.role)
                    .font(.system(size: (geometry.size.height * 0.1)/3))
                    .frame(minWidth: 0, maxWidth: .infinity)
                    .layoutPriority(1)
                Spacer()
                Text("WWDC20")
                    .bold()
                    .font(.system(size: (geometry.size.height * 0.1)/3))
                    .frame(minWidth: 0, maxWidth: .infinity)
                    .layoutPriority(1)
            }
            .animation(nil)
            .padding(.top, (geometry.size.height * 0.08))
            .padding((geometry.size.height * 0.1)/3)
        }
    }
}


struct WWDCCardView: View{
    let cardColor: UIColor
    let userName: String
    let roleName: String
    let userImage: UIImage
    var body: some View{
        CardBackgroundView(color: cardColor)
            .overlay(
                CardForegroundView(
                    name: userName,
                    role: roleName,
                    image: userImage
                )
        )
    }
}

struct CardAnimation: View {
    @State var rotation: Angle = .degrees(0)
    @State var scale: CGFloat = 0
    var card: some View{
        WWDCCardView(
            cardColor: #colorLiteral(red: 0.9529411764705882, green: 0.6862745098039216, blue: 0.13333333333333333, alpha: 1.0),
            userName: "Amit",
            roleName: "Scholar",
            userImage: #imageLiteral(resourceName: "amit"))
            .colorScheme(.light)
    }
    
    var body: some View{
        VStack{
            Text("Let's create your own custom WWDC badge")
                .font(.largeTitle)
            
            card
                .scaleEffect(scale)
                .rotation3DEffect(rotation, axis: (x: 1, y: 1, z: 1))
                .onAppear(perform: animate)
                .padding(100)
        }
        .padding()

    }
    
    func animate(){
        withAnimation(Animation.spring(response: 3, dampingFraction: 0.4, blendDuration: 0)) {
            self.scale = 1
        }
        withAnimation(Animation.easeInOut(duration: 3)) {
            self.rotation = .degrees(360+360+360+360)
        }
    }
}

PlaygroundPage.current.setLiveView(CardAnimation())
PlaygroundPage.current.assessmentStatus = .fail(hints: ["Make sure that you have filled all the fields."], solution: nil)
