/*:
 # Creating WWDC badge in SwiftUI
 We will use all the things you learned in previous pages to build your own customized WWDC badge. Your card will look like what you are seeing on your right.
 
We have used two new modifiers in this page **.scaledToFit()** which tell an ImageView to fit it's content to size it's been proposed, and another is **.overlay(view: View)** which overlays one view on top of another
 > Now go ahead and fill the fields below to create your own custom **WWDC20** badge.
 */
import SwiftUI
//#-hidden-code
import PlaygroundSupport
extension UIColor {
    var shouldBlack: Bool{
        var r:CGFloat = 0
        var g:CGFloat = 0
        var b:CGFloat = 0
        var a:CGFloat = 0
        getRed(&r, green: &g, blue: &b, alpha: &a)
        let colorCheck = (r*255) * 0.299 + (g*255) * 0.587 + (b*255) * 0.114
        return colorCheck < 186
    }
}
//#-end-hidden-code
 
struct WWDCCardView: View{
    //#-hidden-code
    @State var color = UIColor.white
    //#-end-hidden-code
    var body: some View{
        Image("cardmask")
            //#-hidden-code
            .renderingMode(.template)
            //#-end-hidden-code
            .resizable()
            .scaledToFit()
            .foregroundColor(Color(
                //#-hidden-code
                self.store(
                    //#-end-hidden-code
                    /*#-editable-code*/#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)/*#-end-editable-code*/
                    //#-hidden-code
                )
                //#-end-hidden-code
            ))
            .overlay(
                //#-hidden-code
                GeometryReader{ geometry in
                    //#-end-hidden-code
                    VStack{
                        Image(uiImage: /*#-editable-code*/#imageLiteral(resourceName: <#T##String#>)/*#-end-editable-code*/)
                            .resizable()
                            .scaledToFill()
                            //#-hidden-code
                            .frame(width: geometry.size.width/3, height: geometry.size.width/3)
                            //#-end-hidden-code
                            .clipShape(Circle())
                            //#-hidden-code
                            .overlay(
                                Circle()
                                    .stroke(Color(UIColor.label),
                                            lineWidth: 8
                                )
                        )
                        //#-end-hidden-code
                        Text(/*#-editable-code Tap to add your name*/""/*#-end-editable-code*/)
                            .bold()
                            //#-hidden-code
                            .font(.system(size: geometry.size.height * 0.1))
                            .lineLimit(1)
                            .minimumScaleFactor(0.5)
                            .frame(minWidth: 0, maxWidth: .infinity)
                            .layoutPriority(1)
                        //#-end-hidden-code
                        Text(/*#-editable-code Tap to add your designation/role*/""/*#-end-editable-code*/)
                            //#-hidden-code
                            .font(.system(size: (geometry.size.height * 0.1)/3))
                            .frame(minWidth: 0, maxWidth: .infinity)
                            .layoutPriority(1)
                        //#-end-hidden-code
                        Spacer()
                        Text("WWDC20")
                            .bold()
                            //#-hidden-code
                            .font(.system(size: (geometry.size.height * 0.1)/3))
                            .frame(minWidth: 0, maxWidth: .infinity)
                            .layoutPriority(1)
                        //#-end-hidden-code
                    }
                        //#-hidden-code
                        .animation(nil)
                        .padding(.top, (geometry.size.height * 0.08))
                        .padding((geometry.size.height * 0.1)/3)
                    //#-end-hidden-code
                }
                    //#-hidden-code
                    .colorScheme(color.shouldBlack ? .dark : .light)
                //#-end-hidden-code
        )
    }
    //#-hidden-code
    func store(_ color: UIColor) -> UIColor{
        self.color = color
        return color
    }
    //#-end-hidden-code
}
//: When you're ready, hit "Run My Code" to see your whole new customized badge made in **SwiftUI**.
//#-hidden-code
PlaygroundPage.current.wantsFullScreenLiveView = true
PlaygroundPage.current.setLiveViewForSnapshot(
    WWDCCardAnimation{
        WWDCCardView()
    }
)
PlaygroundPage.current.assessmentStatus = .pass(message: "# Congratulations🎊\nYou have created your custom WWDC20 card go ahead share it with your friends and colleagues. Don't forget to try the **view in 3d** and **view in ar**")
//#-end-hidden-code
