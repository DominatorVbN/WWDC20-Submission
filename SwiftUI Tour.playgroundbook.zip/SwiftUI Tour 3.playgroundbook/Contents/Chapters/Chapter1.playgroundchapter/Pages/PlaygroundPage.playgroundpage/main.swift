//: # Welcome to SwiftUI!
//: SwiftUI is an Apple's declarative UI framework, you can use it to create apps for iPhones, iPads, Apple Watch, Apple TV, and Macs.
//:
//: In this playground, you will learn the basics of SwiftUI, starting with the famous first program **Hello world** in SwiftUI.
//:
//: The code below creates a **Text** with the string "Hello world". Hit **"Run My Code"** to see your text rendered on the right.
//:
//: - Note: Don't add modifiers just now, look out for instructions on the right.
import SwiftUI

struct ContentView: View {
    var body: some View{
        //Instantiate a Text struct that takes string as it's argument.
        Text("Hello world")
        //#-editable-code Tap to add modifiers
        //#-end-editable-code
    }
}
//: When you're ready, hit "Run My Code" to see the result.
//#-hidden-code
TextAssessmentManager.shared.showResult {
    ContentView()
}
//#-end-hidden-code
